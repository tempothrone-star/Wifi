"""Strong 4-way handshake verifier — the integrity core of the tool.

This module answers one question with high confidence: *"Does this capture
contain a structurally consistent, complete 4-way EAPOL exchange?"*  Nothing is
kept unless the evidence proves it; everything else is rejected (and, per
policy, deleted).

(Note: this establishes structural consistency — the messages, directions,
nonce/MIC lengths, and replay counters are all sound — not mathematical proof
of every semantic property of the handshake, which would require the PSK.)

Verification is **deterministic and multi-tool**, by design immune to
hallucination:

1. **tshark (Wireshark) is the ground truth.** Every EAPOL-Key frame is read and
   classified M1..M4 from the fields Wireshark decoded — the ``key_ack`` /
   ``install`` flags, the MIC / nonce contents, the message number, and the
   replay counter. We never re-implement bit arithmetic that could drift.
2. **aircrack-ng** — independent "WPA handshake" detector.
3. **hcxpcapngtool** — independent EAPOL-pair / PMKID counter.
4. **cowpatty / pyrit** (when present) — further independent checks.

The verdict is the intersection of the configured detectors. A tool being
*unavailable* is reported truthfully and degrades gracefully — never silently
assumed to pass.

Advanced, packet-level validation (all derived from dissected fields):

* **Completeness** — M1, M2, M3, M4 must all be present (strict mode).
* **Direction** — M1/M3 must come from the AP, M2/M4 from the STA.
* **Nonce & MIC presence and length** — nonce must be 32 bytes (64 hex chars),
  MIC must be 16 bytes (32 hex chars).
* **Replay-counter monotonicity** — within a message pair, the replay counter
  must not decrease (catches malformed/duplicated retransmissions).
* **Retransmission de-duplication** — repeated identical frames are collapsed
  so a duplicated M2 cannot fake completeness.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from ..tools.registry import ToolRegistry
from ..utils.validation import parse_mac

log = logging.getLogger("handshaker.verifier")

_INT_RE = re.compile(r"^-?\d+$")
_HEX_INT_RE = re.compile(r"^0x[0-9a-fA-F]+$")

NONCE_HEX_LEN = 64   # 32 bytes
MIC_HEX_LEN = 32     # 16 bytes


@dataclass
class EapolFrame:
    """One EAPOL-Key frame, classified from fields Wireshark decoded."""

    frame_number: int
    bssid: str
    src: str
    dst: str
    key_info: str          # raw key_info hex (reference/debug only)
    has_ack: bool
    has_install: bool
    has_mic: bool
    mic: str               # WPA Key MIC content (hex)
    nonce: str             # WPA Key Nonce content (hex)
    msgnr: int | None      # Wireshark's own message number (1-4), if present
    replay_counter: int | None
    message: int = 0       # 1..4, 0 = unclassified (our classification)

    @property
    def nonce_valid(self) -> bool:
        """Nonce of correct 32-byte length (when expected)."""
        return len(self.nonce) == NONCE_HEX_LEN

    @property
    def mic_valid(self) -> bool:
        """MIC of correct 16-byte length (when expected)."""
        return len(self.mic) == MIC_HEX_LEN


@dataclass
class HandshakeEvidence:
    """Accumulated, classified EAPOL evidence for a single BSSID."""

    bssid: str
    frames: list[EapolFrame] = field(default_factory=list)
    messages: set[int] = field(default_factory=set)
    # Independent tool signals (None = not run).
    aircrack_confirmed: bool | None = None
    hcx_pairs: int | None = None
    hcx_pmkid: bool | None = None
    cowpatty_confirmed: bool | None = None
    pyrit_confirmed: bool | None = None

    @property
    def has_full_handshake(self) -> bool:
        return {1, 2, 3, 4}.issubset(self.messages)

    @property
    def has_crackable_pair(self) -> bool:
        return 2 in self.messages and 3 in self.messages


def handshake_quality(ev: HandshakeEvidence) -> float:
    """Score a handshake 0.0..1.0 from *measured* facts (pure, deterministic).

    This is the graded signal that replaces the coarse pass/fail for the
    learner. Higher is better; each term is derived only from dissected fields:

    * **Completeness** — full M1-M4 (0.7) > crackable M2+M3 (0.4) > partial (0.1×n).
    * **Distinct-message ratio** — reward captures with the 4 messages each
      present exactly once (clean capture) over ones bloated with
      retransmissions (noisy capture).
    * **Nonce consistency** — a real handshake reuses the ANonce across M1 and
      M3, and the SNonce across M2 (a captured retransmit would diverge).
    """
    if not ev.messages:
        return 0.0

    # Completeness component.
    if ev.has_full_handshake:
        completeness = 0.7
    elif ev.has_crackable_pair:
        completeness = 0.4
    else:
        completeness = 0.1 * len(ev.messages)  # partial credit for any EAPOL

    # Distinct-message ratio: 1.0 when each needed message appears once.
    by_msg: dict[int, int] = {}
    for f in ev.frames:
        if f.message:
            by_msg[f.message] = by_msg.get(f.message, 0) + 1
    needed = {1, 2, 3, 4} if ev.has_full_handshake else {2, 3}
    present = [m for m in needed if m in by_msg]
    if not present:
        return round(completeness, 3)
    distinct_ratio = len(present) / max(sum(by_msg[m] for m in present), len(present))
    distinct_ratio = min(1.0, distinct_ratio)

    # Nonce consistency: M1/M3 share ANonce, M2 has a SNonce.
    m1_nonces = {f.nonce for f in ev.frames if f.message == 1 and f.nonce}
    m3_nonces = {f.nonce for f in ev.frames if f.message == 3 and f.nonce}
    nonce_ok = 0.1 if (m1_nonces and m1_nonces & m3_nonces) else 0.0

    return round(min(1.0, completeness + 0.2 * distinct_ratio + nonce_ok), 3)


@dataclass
class VerificationReport:
    """The final, honest verdict for a capture file."""

    file: str
    passed: bool
    reason: str
    evidence: list[HandshakeEvidence] = field(default_factory=list)
    tools_used: list[str] = field(default_factory=list)
    tools_missing: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "file": self.file,
            "passed": self.passed,
            "reason": self.reason,
            "handshakes": [
                {
                    "bssid": e.bssid,
                    "messages": sorted(e.messages),
                    "full": e.has_full_handshake,
                    "crackable_pair": e.has_crackable_pair,
                    "quality": handshake_quality(e),
                    "aircrack": e.aircrack_confirmed,
                    "hcx_pairs": e.hcx_pairs,
                    "hcx_pmkid": e.hcx_pmkid,
                    "pyrit": e.pyrit_confirmed,
                    "cowpatty": e.cowpatty_confirmed,
                }
                for e in self.evidence
            ],
            "tools_used": self.tools_used,
            "tools_missing": self.tools_missing,
        }


class HandshakeVerifier:
    def __init__(self, registry: ToolRegistry, config: dict) -> None:
        self.registry = registry
        self.config = config["verify"]
        self._tools = list(self.config.get(
            "tools",
            ["tshark", "aircrack-ng", "hcxpcapngtool", "cowpatty", "pyrit", "capinfos"],
        ))

    def _uses(self, tool: str) -> bool:
        """A tool is used only if it is both configured AND installed."""
        return tool in self._tools and self.registry.has(tool)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def verify_file(self, capture_file: str) -> VerificationReport:
        """Verify a single capture file and return a truthful report."""
        path = Path(capture_file)
        if not path.exists() or path.stat().st_size == 0:
            return VerificationReport(file=capture_file, passed=False,
                                      reason="file missing or empty")

        evidence = self._gather_evidence(capture_file)
        report = self._decide(capture_file, evidence)
        log.info("verify %s -> %s (%s)", Path(capture_file).name,
                 "PASS" if report.passed else "REJECT", report.reason)
        return report

    # ------------------------------------------------------------------ #
    # Evidence gathering
    # ------------------------------------------------------------------ #
    def _gather_evidence(self, capture_file: str) -> list[HandshakeEvidence]:
        by_bssid: dict[str, HandshakeEvidence] = {}

        # 1) tshark EAPOL ground truth.
        if self._uses("tshark"):
            for f in self._parse_tshark(capture_file):
                ev = by_bssid.setdefault(f.bssid, HandshakeEvidence(bssid=f.bssid))
                ev.frames.append(f)
                if f.message:
                    ev.messages.add(f.message)

        # 2) aircrack-ng independent check.
        aircrack_bssids: set[str] | None = None
        if self._uses("aircrack-ng"):
            res = self.registry.aircrack().check_handshakes(capture_file)
            aircrack_bssids = self.registry.aircrack().parse_handshakes(res)

        # 3) hcxpcapngtool independent EAPOL pair / PMKID count.
        hcx_pairs, hcx_pmkid = self._hcx_report(capture_file)

        # 4) pyrit — independent handshake-quality analysis (good/workable).
        pyrit_bssids: set[str] | None = self._pyrit_report(capture_file)

        # 5) cowpatty — independent 4-way-frame check, per BSSID (needs ESSID).
        cowpatty_map: dict[str, bool] = self._cowpatty_report(capture_file)

        for bssid, ev in by_bssid.items():
            ev.aircrack_confirmed = (bssid in aircrack_bssids) if aircrack_bssids is not None else None
            ev.hcx_pairs = hcx_pairs
            ev.hcx_pmkid = hcx_pmkid
            ev.pyrit_confirmed = (bssid in pyrit_bssids) if pyrit_bssids is not None else None
            ev.cowpatty_confirmed = cowpatty_map.get(bssid) if cowpatty_map else None

        if aircrack_bssids:
            for b in aircrack_bssids:
                ev = by_bssid.setdefault(b, HandshakeEvidence(bssid=b))
                ev.aircrack_confirmed = True
                ev.hcx_pairs = hcx_pairs
                ev.hcx_pmkid = hcx_pmkid
                ev.pyrit_confirmed = (b in pyrit_bssids) if pyrit_bssids is not None else None
                ev.cowpatty_confirmed = cowpatty_map.get(b) if cowpatty_map else None

        return list(by_bssid.values())

    # ------------------------------------------------------------------ #
    # Decision
    # ------------------------------------------------------------------ #
    def _decide(self, capture_file: str, evidence: list[HandshakeEvidence]) -> VerificationReport:
        tools_used, tools_missing = self._tool_status()

        if not evidence:
            return VerificationReport(
                file=capture_file, passed=False,
                reason="no EAPOL frames found (not a handshake capture)",
                tools_used=tools_used, tools_missing=tools_missing,
            )

        require_full = bool(self.config["require_full_handshake"])
        min_packets = int(self.config.get("min_packets", 4))
        structural = bool(self.config.get("structural_checks", True))

        # Per-BSSID verdict. A capture is accepted when AT LEAST ONE BSSID holds
        # a genuine handshake — an unrelated, incomplete AP in the same capture
        # (common with channel-level hcxdumptool filtering) must not reject the
        # valid one.
        passed_bssids: list[str] = []
        failures: list[str] = []
        for ev in evidence:
            problem = self._bssid_problem(ev, require_full, min_packets, structural)
            if problem is None:
                passed_bssids.append(ev.bssid)
            else:
                failures.append(f"{ev.bssid}: {problem}")

        if passed_bssids:
            return VerificationReport(
                file=capture_file, passed=True,
                reason=f"valid 4-way handshake for {', '.join(passed_bssids)}",
                evidence=evidence, tools_used=tools_used, tools_missing=tools_missing,
            )
        return VerificationReport(
            file=capture_file, passed=False,
            reason="; ".join(failures) if failures else "no valid handshake found",
            evidence=evidence, tools_used=tools_used, tools_missing=tools_missing,
        )

    def _bssid_problem(self, ev: HandshakeEvidence, require_full: bool,
                       min_packets: int, structural: bool) -> str | None:
        """Return a reason this BSSID's handshake is invalid, or None if valid.

        Checks are all evaluated PER BSSID (not per file): completeness,
        per-BSSID packet count, structural validity, and tool contradictions.
        """
        # Completeness.
        if require_full and not ev.has_full_handshake:
            return (f"incomplete handshake (messages={sorted(ev.messages)}), "
                    "full M1-M4 required")
        if not require_full and not ev.has_crackable_pair:
            return f"no crackable M2+M3 pair (messages={sorted(ev.messages)})"

        # Per-BSSID minimum EAPOL frames (not a global file total).
        if len(ev.frames) < min_packets:
            return f"too few EAPOL frames ({len(ev.frames)} < {min_packets})"

        # Packet-level structural validation (when enabled).
        if structural:
            problem = _structural_problem(ev)
            if problem:
                return problem

        # Contradiction checks: if a tool explicitly says NO, reject.
        if ev.aircrack_confirmed is False:
            return "aircrack-ng does not confirm a WPA handshake"
        if ev.pyrit_confirmed is False:
            return "pyrit found no good/workable handshake"
        if ev.cowpatty_confirmed is False:
            return "cowpatty does not confirm a complete 4-way handshake"
        return None

    def _tool_status(self) -> tuple[list[str], list[str]]:
        used, missing = [], []
        for name in self._tools:
            (used if self.registry.has(name) else missing).append(name)
        return used, missing

    # ------------------------------------------------------------------ #
    # tshark parsing
    # ------------------------------------------------------------------ #
    def _parse_tshark(self, capture_file: str) -> list[EapolFrame]:
        res = self.registry.tshark().eapol_frames(capture_file)
        frames: list[EapolFrame] = []
        seen: set[tuple] = set()  # de-duplicate identical retransmissions
        for line in res.stdout.splitlines():
            parts = line.split(",")
            if len(parts) < 11:
                continue
            bssid = parse_mac(parts[1])
            if not bssid:
                continue
            frame_number = _parse_int_field(parts[0]) or 0
            src = parse_mac(parts[2]) or parts[2]
            dst = parse_mac(parts[3]) or parts[3]
            key_info = parts[4].strip()
            has_ack = parts[5].strip() == "1"
            has_install = parts[6].strip() == "1"
            mic = parts[7].strip()
            nonce = parts[8].strip()
            msgnr = _parse_int_field(parts[9])
            replay_counter = _parse_counter(parts[10])

            frame = EapolFrame(
                frame_number=frame_number, bssid=bssid, src=src, dst=dst,
                key_info=key_info, has_ack=has_ack, has_install=has_install,
                has_mic=bool(mic), mic=mic, nonce=nonce, msgnr=msgnr,
                replay_counter=replay_counter,
            )
            frame.message = _classify_message(frame)

            # De-duplicate: same (bssid, src, dst, message, nonce) = retransmit.
            dedup_key = (bssid, src, dst, frame.message, nonce)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)
            frames.append(frame)
        return frames

    # ------------------------------------------------------------------ #
    # hcxpcapngtool
    # ------------------------------------------------------------------ #
    def _hcx_report(self, capture_file: str) -> tuple[int | None, bool | None]:
        if not self._uses("hcxpcapngtool"):
            return None, None
        import os
        tmp = os.environ.get("TMPDIR", "/tmp")
        out = f"{tmp}/handshaker_hcx_{Path(capture_file).stem}.22000"
        res = self.registry.hcxpcapngtool().convert(capture_file, out)
        pairs = None
        m = re.search(r"EAPOL pairs\s*:\s*(\d+)", res.output, re.IGNORECASE)
        if m:
            pairs = int(m.group(1))
        else:
            m = re.search(r"EAPOL M1M2 messages\s*:\s*(\d+)", res.output, re.IGNORECASE)
            if m:
                pairs = int(m.group(1))
        pmkid = None
        m = re.search(r"PMKID.*?:\s*(\d+)", res.output, re.IGNORECASE)
        if m:
            pmkid = int(m.group(1)) > 0
        return pairs, pmkid

    # ------------------------------------------------------------------ #
    # pyrit — independent handshake-quality analysis
    # ------------------------------------------------------------------ #
    def _pyrit_report(self, capture_file: str) -> set[str] | None:
        """Return the set of BSSIDs pyrit rates as ``good``/``workable``.

        ``None`` means pyrit was not run (not configured/installed, or it
        errored without producing parseable analysis). An empty set means pyrit
        ran and found no usable handshake — a real signal.
        """
        if not self._uses("pyrit"):
            return None
        res = self.registry.pyrit().check_handshakes(capture_file)
        if not res.ok and "AccessPoint" not in res.output:
            log.info("pyrit did not produce analysis output; treating as not run")
            return None
        return parse_pyrit(res)

    # ------------------------------------------------------------------ #
    # cowpatty — independent 4-way-frame check, per BSSID (needs an ESSID)
    # ------------------------------------------------------------------ #
    def _cowpatty_report(self, capture_file: str) -> dict[str, bool]:
        """Run cowpatty ``-c`` once per BSSID against its own ESSID.

        cowpatty checks a *specific* network, so a single run is NOT valid for a
        multi-AP capture. Returns ``{bssid: confirmed}`` for every BSSID whose
        ESSID is known (empty dict when cowpatty is absent or no ESSID found).
        """
        out: dict[str, bool] = {}
        if not self._uses("cowpatty"):
            return out
        essid_map = self.registry.tshark().essids(capture_file) if self._uses("tshark") else {}
        if not essid_map:
            log.info("cowpatty skipped: no ESSID extracted from capture")
            return out
        for bssid, essid in essid_map.items():
            res = self.registry.cowpatty().check_handshake(capture_file, essid)
            confirmed = parse_cowpatty(res)
            if confirmed is not None:
                out[bssid] = confirmed
        return out

    # ------------------------------------------------------------------ #
    # capinfos — capture metadata sanity (packet count)
    # ------------------------------------------------------------------ #
    def capinfos_packets(self, capture_file: str) -> int | None:
        """Return the packet count from ``capinfos`` (None if unavailable)."""
        if not self._uses("capinfos"):
            return None
        res = self.registry.capinfos().info(capture_file)
        return parse_capinfos_packets(res)


# --------------------------------------------------------------------------- #
# Pure helpers (unit-testable)
# --------------------------------------------------------------------------- #
def _parse_int_field(value: str) -> int | None:
    v = value.strip()
    if _INT_RE.match(v):
        return int(v)
    return None


def _parse_counter(value: str) -> int | None:
    """Parse a replay counter that tshark prints as hex (``0x...``) or decimal.

    Wireshark renders the 8-byte EAPOL replay counter as hex in ``-T fields``
    output, so a plain int parser would silently drop it. Handles both.
    """
    v = value.strip()
    if _INT_RE.match(v):
        return int(v)
    if _HEX_INT_RE.match(v):
        return int(v, 16)
    return None


def _classify_message(f: EapolFrame) -> int:
    """Classify an EAPOL-Key frame as M1..M4, or 0 if ambiguous.

    Pure lookup from Wireshark's decoded flags:

        M1: Key ACK set, no MIC            (ANonce)
        M3: Key ACK + Install + MIC        (GTK)
        M2: MIC, no ACK/Install, nonce     (SNonce)
        M4: MIC, no ACK/Install, no nonce
    """
    has_nonce = bool(f.nonce)
    if f.has_ack and not f.has_mic:
        return 1
    if f.has_mic and f.has_ack and f.has_install:
        return 3
    if f.has_mic and not f.has_ack and not f.has_install:
        return 2 if has_nonce else 4
    return 0


def _structural_problem(ev: HandshakeEvidence) -> str | None:
    """Return a human-readable structural defect, or None if sound.

    Checks (all from dissected fields, no inference):

    1. Direction: M1/M3 originate from the AP; M2/M4 from the STA.
    2. Nonce presence: M1 carries the ANonce, M2 the SNonce.
    3. Nonce / MIC length: 32-byte nonce (64 hex), 16-byte MIC (32 hex).
    4. Replay counter monotonicity — **per direction**. The AP and STA keep
       independent replay counters; comparing across directions would falsely
       reject valid handshakes.
    """
    by_msg: dict[int, list[EapolFrame]] = {1: [], 2: [], 3: [], 4: []}
    for f in ev.frames:
        if f.message in by_msg:
            by_msg[f.message].append(f)

    ap_mac = _ap_mac(ev)
    sta_mac = _sta_mac(ev)

    # Direction checks.
    if ap_mac:
        for msg in (1, 3):
            for f in by_msg[msg]:
                if parse_mac(f.src) != ap_mac:
                    return f"message {msg} did not originate from the AP (src={f.src})"
    if sta_mac:
        for msg in (2, 4):
            for f in by_msg[msg]:
                if parse_mac(f.src) != sta_mac:
                    return f"message {msg} did not originate from the STA (src={f.src})"

    # Nonce presence: M1 (ANonce) and M2 (SNonce) must carry a nonce.
    if not any(f.nonce for f in by_msg[1]):
        return "message 1 is missing its ANonce"
    if not any(f.nonce for f in by_msg[2]):
        return "message 2 is missing its SNonce"

    # Nonce / MIC structural checks (length validation on the dissected hex).
    for msg in (1, 2, 3):
        for f in by_msg[msg]:
            if f.nonce and len(f.nonce) != NONCE_HEX_LEN:
                return f"message {msg} has a malformed nonce length ({len(f.nonce)})"
    for msg in (2, 3, 4):
        for f in by_msg[msg]:
            if f.mic and len(f.mic) != MIC_HEX_LEN:
                return f"message {msg} has a malformed MIC length ({len(f.mic)})"

    # Replay counter monotonicity — PER-DIRECTION (per transmitter).
    by_src: dict[str, list[EapolFrame]] = {}
    for f in ev.frames:
        by_src.setdefault(f.src, []).append(f)
    for src, frames in by_src.items():
        seq = sorted(frames, key=lambda f: f.frame_number)
        last_rc: int | None = None
        for f in seq:
            if f.replay_counter is None:
                continue
            if last_rc is not None and f.replay_counter < last_rc:
                return f"replay counter decreased for {src}: {f.replay_counter} < {last_rc}"
            last_rc = f.replay_counter

    return None


def _ap_mac(ev: HandshakeEvidence) -> str | None:
    """Infer the AP MAC from the bssid (the authenticator owns the BSSID)."""
    return ev.bssid


def _sta_mac(ev: HandshakeEvidence) -> str | None:
    """Infer the STA MAC as the M2/M4 transmitter, if observed."""
    for f in ev.frames:
        if f.message in (2, 4):
            mac = parse_mac(f.src)
            if mac and mac != ev.bssid:
                return mac
    return None


# --------------------------------------------------------------------------- #
# Independent-verifier output parsers (pure, unit-testable)
# --------------------------------------------------------------------------- #
_ACCESSPOINT_RE = re.compile(r"AccessPoint\s+([0-9A-Fa-f:]{17})", re.IGNORECASE)
_GOOD_RE = re.compile(r"\b(good|workable)\b", re.IGNORECASE)


def parse_pyrit(result) -> set[str]:
    """Extract BSSIDs pyrit rates as ``good``/``workable`` from ``analyze`` output.

    pyrit prints one ``AccessPoint <bssid>`` line per AP, with per-station
    handshake lines beneath. Only APs that have at least one ``good`` or
    ``workable`` handshake are returned. An empty set means pyrit ran but found
    nothing usable.
    """
    confirmed: set[str] = set()
    current_bssid: str | None = None
    for line in result.output.splitlines():
        m = _ACCESSPOINT_RE.search(line)
        if m:
            current_bssid = parse_mac(m.group(1))
            continue
        # A "good"/"workable" handshake line belongs to the current AP.
        if current_bssid and _GOOD_RE.search(line):
            confirmed.add(current_bssid)
    return confirmed


_COWPATTY_OK_RE = re.compile(r"collected all necessary data", re.IGNORECASE)
_COWPATTY_FAIL_RE = re.compile(r"(no valid|unable to identify|not found)", re.IGNORECASE)


def parse_cowpatty(result) -> bool | None:
    """Interpret cowpatty ``-c`` output.

    * ``True``  — cowpatty found a complete handshake (documented phrase).
    * ``False`` — cowpatty ran and reported no valid handshake.
    * ``None``  — cowpatty errored / produced no parseable output (honest
      "unknown", distinct from a real "no handshake" finding).

    We never claim confirmation without the documented phrase.
    """
    if _COWPATTY_OK_RE.search(result.output):
        return True
    if _COWPATTY_FAIL_RE.search(result.output):
        return False
    if not result.ok and not result.output.strip():
        return None
    return None


_CAPINFOS_PACKETS_RE = re.compile(r"Number of packets:\s*([\d,]+)", re.IGNORECASE)


def parse_capinfos_packets(result) -> int | None:
    """Extract the packet count from capinfos output, or None."""
    m = _CAPINFOS_PACKETS_RE.search(result.output)
    if not m:
        return None
    return int(m.group(1).replace(",", ""))
